Aquesta aplicació web s'inicialitza de manera personalitzada amb les persones que viuen al pis i els productes que comparteixen. L'app permet a través d'una interfície web introduïr les compres que es fan, afegir nous productes compartits, saber qui ha estat l'últim en comprar un producte específic, veure les últimes compres i esborrar-ne la darrera. Es recomana descarregar els arxius en una màquina que pugui estar sempre activa per actuar correctament de servidor. Per instal·lar i inicialitzar l'app només cal executar l'arxiu "crearDB.sh".

Software necessari:
- Apache Web Server
- Mysql
- PHP 5 o posterior
